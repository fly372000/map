<template>
  <div>

    <el-button type="primary"
               plain
               @click="change_img()">切换影像底图</el-button>
    <el-button type="primary"
               plain
               @click="change_vec()">切换街道底图</el-button>
    <el-button type="primary"
               plain
               @click="change_ter()">切换地形底图</el-button>
    <el-button type="primary"
               plain
               @click="change_google()">切换谷歌卫星地图</el-button>
    <el-button type="primary"
               plain
               @click="change_google_tile()">切换谷歌路网地图</el-button>
  </div>
  <div id="map"
       ref="rootmap">
  </div>
</template>
 
<script>
import "ol/ol.css";
import { Map, View } from "ol";
import { VectorTile as VectorLayerTile, Tile } from 'ol/layer'
import { Style, Fill, Stroke } from 'ol/style';
import { VectorTile as VectorSourceTile, OSM, WMTS, XYZ } from 'ol/source'
import { fromLonLat } from 'ol/proj'
import { defaults } from 'ol/control'

export default {
  name: 'OlChangeMap',
  data () {
    return {
      map: null,
      img: null,
      map_cva: null,
      map_vec: null,
      map_ter: null,
      map_cta: null,
      map_google: null,
      map_google_Tile: null
    };
  },
  mounted () {
    this.img = new Tile({
      source: new XYZ({  //天地图
        url: 'http://t3.tianditu.com/DataServer?T=img_w&x={x}&y={y}&l={z}&tk=9210a24efc38b6941d668814aba28cfd'
      }),
      visible: true
    });
    this.map_cva = new Tile({
      source: new XYZ({
        url: "http://t4.tianditu.com/DataServer?T=vec_w&x={x}&y={y}&l={z}&tk=9210a24efc38b6941d668814aba28cfd"
      }),
      visible: false
    });
    this.map_vec = new Tile({
      source: new XYZ({
        url: "http://t4.tianditu.com/DataServer?T=vec_w&x={x}&y={y}&l={z}&tk=9210a24efc38b6941d668814aba28cfd"
      }),
      visible: false
    });
    this.map_ter = new Tile({
      source: new XYZ({
        url: "http://t4.tianditu.com/DataServer?T=ter_w&x={x}&y={y}&l={z}&tk=9210a24efc38b6941d668814aba28cfd"
      }),
      visible: false
    });
    this.map_cta = new Tile({
      source: new XYZ({
        url: "http://t4.tianditu.com/DataServer?T=cva_w&x={x}&y={y}&l={z}&tk=9210a24efc38b6941d668814aba28cfd"
      }),
      visible: false
    });
    this.map_google = new Tile({
      source: new XYZ({
        url: "http://www.google.cn/maps/vt?lyrs=s@189&gl=cn&x={x}&y={y}&z={z}"
      }),
      visible: false
    });
    this.map_google_Tile = new Tile({
      source: new XYZ({
        url: "http://www.google.cn/maps/vt?lyrs=r@189&gl=cn&x={x}&y={y}&z={z}"
      }),
      visible: false
    });
    this.map = new Map({
      target: 'map',
      layers: [
        this.img, this.map_cva, this.map_vec,
        this.map_ter, this.map_cta, this.map_google, this.map_google_Tile
      ],
      controls: defaults({
        attributionOptions: {
          collapsible: false
        }
      }),
      view: new View({
        center: fromLonLat([116.24, 39.55]),//将坐标从经度,纬度转换为不同的投影,默认为'EPSG：3857'。
        zoom: 10
      })
    })
  },
  methods: {
    change_img () {
      this.img.setVisible(true);
      this.map_cva.setVisible(false);
      this.map_vec.setVisible(false);
      this.map_ter.setVisible(false);
      this.map_cta.setVisible(false);
      this.map_google.setVisible(false);
      this.map_google_Tile.setVisible(false);
    },
    change_vec () {
      this.img.setVisible(false);
      this.map_cva.setVisible(true);
      this.map_vec.setVisible(false);
      this.map_ter.setVisible(false);
      this.map_cta.setVisible(false);
      this.map_google.setVisible(false);
      this.map_google_Tile.setVisible(false);
    },
    change_ter () {
      this.img.setVisible(false);
      this.map_cva.setVisible(false);
      this.map_vec.setVisible(false);
      this.map_ter.setVisible(true);
      this.map_cta.setVisible(false);
      this.map_google.setVisible(false);
      this.map_google_Tile.setVisible(false);
    },
    change_google () {
      this.img.setVisible(false);
      this.map_cva.setVisible(false);
      this.map_vec.setVisible(false);
      this.map_ter.setVisible(false);
      this.map_cta.setVisible(false);
      this.map_google.setVisible(true);
      this.map_google_Tile.setVisible(false);
    },
    change_google_tile () {
      this.img.setVisible(false);
      this.map_cva.setVisible(false);
      this.map_vec.setVisible(false);
      this.map_ter.setVisible(false);
      this.map_cta.setVisible(false);
      this.map_google.setVisible(false);
      this.map_google_Tile.setVisible(true);
    }
  }
};
</script>
 
<style>
#map {
  height: 600px;
  width: 100%;
}
/*隐藏ol的一些自带元素*/
.ol-attribution,
.ol-zoom {
  display: none;
}
</style>



