<template>
    <el-card shadow="never" class="index">
        <template #header>
            <div class="card_header">
                <b>表单数据</b>
            </div>
        </template>
        <el-empty description="暂无数据"></el-empty>
    </el-card>
</template>

<script></script>

<style lang="scss" scoped>
.card_header {
    display: flex;
    align-items: center;
    justify-content: space-between;
}
</style>
