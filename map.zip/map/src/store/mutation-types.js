// 清除用户信息
export const CLEAR_USER = "CLEAR_USER";
// 存储用户信息
export const SET_USER = "SET_USER";
// 存储路由菜单
export const SET_ROUTES = "SET_ROUTES";
