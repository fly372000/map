import Layout from "../layout/Index.vue";
import RouteView from "../components/RouteView.vue";

const layoutMap = [
    {
        path: "",
        name: "Index",
        meta: { title: "淹没可视化", icon: "HomeFilled" },
        component: () => import("../views/Index.vue")
    },
    {
      path: "olmap",
      name: "plmap",
      meta: { title: "可视化", icon: "map" },
      component: () => import("../components/olmap.vue")
  },
    {
        path: "data",
        name: "Data",
        component: RouteView,
        meta: { title: "淹没面积一览", icon: "DataLine" },
        children: [
            {
                path: "",
                name: "DataList",
                meta: { title: "各流域淹没情况" },
                component: () => import("../views/data/List.vue")
            },
            {
                path: "table",
                name: "DataTable",
                meta: { title: "数据表格", roles: ["admin"] },
                component: () => import("../views/data/Table.vue")
            }
        ]
    },
    {
        path: "admin",
        name: "Admin",
        meta: { title: "用户管理", icon: "User", roles: ["admin"] },
        component: RouteView,
        children: [
            {
                path: "",
                name: "AdminAuth",
                meta: { title: "用户列表" },
                component: () => import("../views/admin/AuthList.vue")
            },
            {
                path: "role",
                name: "AdminRole",
                meta: { title: "角色列表" },
                component: () => import("../views/admin/RoleList.vue")
            }
        ]
    },
    {
        path: "player",
        name: "Player",
        meta: { title: "淹没模拟动画", icon: "Film" },
        component: () => import("../views/common/XGPlayer.vue")
    },
    {
        path: "charts",
        name: "Charts",
        meta: { title: "数据可视化", icon: "trend-charts" },
        component: () => import("../views/data/Charts.vue")
    },
    {
        path: "editor",
        name: "Editor",
        meta: { title: "项目简介", icon: "Document" },
        component: () => import("../views/common/Editor.vue")
    },
    {
        path: "user",
        name: "User",
        hidden: true /* 不在侧边导航展示 */,
        meta: { title: "个人中心" },
        component: () => import("../views/admin/User.vue")
    },
    {
        path: "/error",
        name: "NotFound",
        hidden: true,
        meta: { title: "404" },
        component: () => import("../components/NotFound.vue")
    },
    {
        path: "/:w+",
        hidden: true,
        redirect: { name: "NotFound" }
    }
];

const routes = [
    { path: "/login", name: "Login", meta: { title: "登录" }, component: () => import("../views/login/Login.vue") },
    { path: "/", name: "Layout", component: Layout, children: [...layoutMap] }
];

export { routes, layoutMap };
